Windows: start-debug.cmd を起動し、表示されるローカル版URLを開いてください。WSLのPython3とg++、またはWindowsのPythonとg++が必要です。公開サイトからも接続キーで接続できます。自分で確認したコードだけを実行してください。コードは本人の権限で動きます。終了はCtrl+C。
